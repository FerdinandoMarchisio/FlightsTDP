package it.polito.tdp.flightdelays.db;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import it.polito.tdp.flightdelays.model.Airline;
import it.polito.tdp.flightdelays.model.Airport;
import it.polito.tdp.flightdelays.model.Flight;
import it.polito.tdp.flightdelays.model.NextVolo;
import it.polito.tdp.flightdelays.model.Passaggero;

public class FlightDelaysDAO {

	public List<Airline> loadAllAirlines() {
		String sql = "SELECT * from airlines";
		List<Airline> result = new ArrayList<Airline>();

		try {
			Connection conn = ConnectDB.getConnection();
			PreparedStatement st = conn.prepareStatement(sql);
			ResultSet rs = st.executeQuery();

			while (rs.next()) {
				result.add(new Airline(rs.getInt("ID"),rs.getString("IATA_CODE"), rs.getString("airline")));
			}

			conn.close();
			return result;

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Errore connessione al database");
			throw new RuntimeException("Error Connection Database");
		}
	}

	public List<Airport> loadAllAirports() {
		String sql = "SELECT * FROM airports";
		List<Airport> result = new ArrayList<Airport>();
		
		try {
			Connection conn = ConnectDB.getConnection();
			PreparedStatement st = conn.prepareStatement(sql);
			ResultSet rs = st.executeQuery();

			while (rs.next()) {
				Airport airport = new Airport(rs.getInt("ID"), rs.getString("IATA_CODE"), rs.getString("AIRPORT"), rs.getString("CITY"),
						rs.getString("STATE"), rs.getString("COUNTRY"), rs.getDouble("LATITUDE"), rs.getDouble("LONGITUDE"), rs.getDouble("TIMEZONE_OFFSET"));
				result.add(airport);
			}
			
			conn.close();
			return result;
			
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Errore connessione al database");
			throw new RuntimeException("Error Connection Database");
		}
	}

	public List<Flight> loadAllFlights(int i) {
		String sql = "SELECT * FROM flights WHERE AIRLINE_ID = ?";
		List<Flight> result = new LinkedList<Flight>();

		try {
			Connection conn = ConnectDB.getConnection();
			PreparedStatement st = conn.prepareStatement(sql);
			st.setInt(1, i);
			ResultSet rs = st.executeQuery();

			while (rs.next()) {
				Flight flight = new Flight(rs.getInt("ID"), rs.getInt("AIRLINE_ID"), rs.getInt("FLIGHT_NUMBER"), rs.getInt("ORIGIN_AIRPORT_ID"), rs.getInt("DESTINATION_AIRPORT_ID"),
						rs.getDate("SCHEDULED_DEPARTURE_DATE").toLocalDate(), rs.getDate("ARRIVAL_DATE").toLocalDate(), rs.getDouble("DEPARTURE_DELAY"), rs.getDouble("ARRIVAL_DELAY"), rs.getInt("DISTANCE"));
				result.add(flight);
			}

			conn.close();
			return result;

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Errore connessione al database");
			throw new RuntimeException("Error Connection Database");
		}
	}

	public double getRitardoMedio(Airport o, Airport d, int id) {
		String sql = "select  avg(f.ARRIVAL_DELAY) as avg \n" + 
				"from flights as f \n" + 
				"where f.AIRLINE_ID = ? \n" + 
				"and f.ORIGIN_AIRPORT_ID = ? \n" + 
				"and f.DESTINATION_AIRPORT_ID = ? ";
		
		double media=0;

		try {
			Connection conn = ConnectDB.getConnection();
			PreparedStatement st = conn.prepareStatement(sql);
			st.setInt(1, id);
			st.setInt(2, o.getId());
			st.setInt(3, d.getId());
			
			ResultSet rs = st.executeQuery();

			while (rs.next()) {
				media = rs.getDouble("avg");
			}

			conn.close();
			return media;

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Errore connessione al database");
			throw new RuntimeException("Error Connection Database");
		}
		
	}

	public NextVolo nextVolo(Passaggero p, Airline a) {
		
         Airport current = p.getCurrent();
		
		String sql = "select f.ARRIVAL_DATE as date, f.DESTINATION_AIRPORT_ID as id, f.ARRIVAL_DELAY as delay \n" + 
				"from flights as f, airlines as a  \n" + 
				"where a.ID = f.AIRLINE_ID \n" + 
				"and a.ID = ? \n" + 
				"and f.ORIGIN_AIRPORT_ID = ? \n" + 
				//"and f.SCHEDULED_DEPARTURE_DATE>? \n" + 
				"order by f.SCHEDULED_DEPARTURE_DATE";
		
		

		try {
			Connection conn = ConnectDB.getConnection();
			PreparedStatement st = conn.prepareStatement(sql);
			
			st.setInt(1, a.getId());
			st.setInt(2, current.getId());
			
			
			
			ResultSet rs = st.executeQuery();

			NextVolo next=null;
			if(rs.next()) {
			 next = new NextVolo( rs.getInt("id"),rs.getDouble("delay"), rs.getDate("date"));
			}
			
			
		
			

			conn.close();
			return next;
			

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Errore connessione al database");
			throw new RuntimeException("Error Connection Database");
		}
	}

	public NextVolo nextVolo1(Passaggero p, Airline a) {
		 Airport current = p.getCurrent();
			
			String sql = "select f.ARRIVAL_DATE as date, f.DESTINATION_AIRPORT_ID as id, f.ARRIVAL_DELAY as delay \n" + 
					"from flights as f, airlines as a  \n" + 
					"where a.ID = f.AIRLINE_ID \n" + 
					"and a.ID = ? \n" + 
					"and f.ORIGIN_AIRPORT_ID = ? \n" + 
					"and f.SCHEDULED_DEPARTURE_DATE>? \n" + 
					"order by f.SCHEDULED_DEPARTURE_DATE";
			
			

			try {
				Connection conn = ConnectDB.getConnection();
				PreparedStatement st = conn.prepareStatement(sql);
				
				st.setInt(1, a.getId());
				st.setInt(2, current.getId());
				st.setDate(3, p.getDate());
				
				
				
				ResultSet rs = st.executeQuery();
				NextVolo next=null;
				if(rs.next()) {
				 next = new NextVolo( rs.getInt("id"),rs.getDouble("delay"), rs.getDate("date"));
				}
				
			
				

				conn.close();
				return next;
				

			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("Errore connessione al database");
				throw new RuntimeException("Error Connection Database");
			}
	}

	
}
