package it.polito.tdp.flightdelays.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

import org.jgrapht.Graph;
import org.jgrapht.graph.DefaultWeightedEdge;

import it.polito.tdp.flightdelays.db.FlightDelaysDAO;

public class Simulazione {
	
	int passeggeri;
	int voli;
	Airline a ;
	
	List<Airport> porti = new ArrayList<Airport>();
	Map<Integer, Airport> portiM = new TreeMap<Integer, Airport>();
	
	FlightDelaysDAO dao = new FlightDelaysDAO();
	
	Graph<Airport, DefaultWeightedEdge> grafo;
	
	List<Passaggero> pass = new ArrayList<Passaggero>();

	public Simulazione(int passeggeri, int voli2, Airline a,Graph<Airport, DefaultWeightedEdge> graph) {
		this.a = a;
		this.passeggeri = passeggeri;
		this.voli = voli2;
		this.grafo = graph;
		
		this.inizializza();
		
		this.distribuzionePasseggeri();
		
		
		// TODO Auto-generated constructor stub
	}

	private void inizializza() {
		for(Airport a : this.grafo.vertexSet()) {
			if(this.grafo.degreeOf(a)>0) {
				this.porti.add(a);
				this.portiM.put(a.getId(), a);
			}
		}
		
		
	}

	private void distribuzionePasseggeri() {
		this.pass.clear();
		
		for(Airport a : this.grafo.vertexSet()) {
			a.reSetPipo();
		}
		
			
		Random rG = new Random();
		int p = this.passeggeri;
	
		while(p>0) {
			int aN = rG.nextInt(this.porti.size()-1)+1;
		    int pass =  rG.nextInt(p)+1;
		    	    
		    Airport a = this.porti.get(aN);
		    a.setPipol(pass);
		    Passaggero passenger = new Passaggero(a,a);
		    //System.out.println(passenger);
		    this.pass.add(passenger);
		   // System.out.println("Aggiunto un passeggero in "+a.getName()+"\n");
		    p-=pass;
		    
		    
		    
		}
		
		
		
		
		
		
		
	}
	
	public List<Passaggero> doSimulazione(){
		for(Passaggero p : this.pass) {
			while(p.count<this.voli) {
				this.nextVolo(p);
			}
		}
		
		return this.pass;
	}

	private void nextVolo(Passaggero p) {
		NextVolo next;
		if(p.getDate()==null) {
		 next = this.dao.nextVolo(p, a);
		}
		else {
			next = this.dao.nextVolo1(p,a);
			
		}
		if(next==null) {
			p.setCount(this.voli);
			return;
		}
		else {
	    Airport newAirport = this.portiM.get(next.nextAirportID);
	    p.current = newAirport;
	    
	    p.setRitardo(next.ritardo);
	    
	    p.setDate(next.newDate);
	    
	    p.setCount(1);
		}
		
	}

	
	
	
	
	
	
	
}
