package it.polito.tdp.flightdelays.model;

public class Airport {

	private int id;
	private String code;
	private String name;
	private String city;
	private String state;
	private String country;
	private double latitude;
	private double longitude;
	private double timeZoneOff;
	private int pipol;
	
	public Airport(int id, String code, String name, String city, String state, String country, double latitude,
			double longitude, double timeZoneOff) {
		this.id = id;
		this.code = code;
		this.name = name;
		this.city = city;
		this.state = state;
		this.country = country;
		this.latitude = latitude;
		this.longitude = longitude;
		this.timeZoneOff = timeZoneOff;
		this.pipol = 0;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	
	

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public double getTimeZoneOff() {
		return timeZoneOff;
	}

	public void setTimeZoneOff(double timeZoneOff) {
		this.timeZoneOff = timeZoneOff;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Airport [name=");
		builder.append(name);
		builder.append("]");
		return builder.toString();
	}
	
	public void setPipol(int p) {
		this.pipol =p;
	}
	
	public int getPipol() {
		return this.pipol;
	}
	
	public void reSetPipo() {
		this.pipol =0;
	}
	
}
