package it.polito.tdp.flightdelays.model;

public class Tratta {
	
	Airport o;
	Airport d;
	double ritardo;
	
	public Tratta(Airport o2, Airport d2, double peso) {
		// TODO Auto-generated constructor stub
		this.o = o2;
		this.d = d2;
		this.ritardo = peso;
	}

	@Override
	public String toString() {
		return "Tratta: "+o.getCode()+" - "+d.getCode()+" Ritardo: "+ritardo;
	}
	
	

}
