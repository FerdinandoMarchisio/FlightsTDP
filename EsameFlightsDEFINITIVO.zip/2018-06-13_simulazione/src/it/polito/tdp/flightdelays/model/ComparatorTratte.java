package it.polito.tdp.flightdelays.model;

import java.util.Comparator;

public class ComparatorTratte implements Comparator<Tratta> {

	@Override
	public int compare(Tratta t1, Tratta t2) {
		if(t1.ritardo>t2.ritardo)
			return -1;
		
		else
			return +1;
	}

}
