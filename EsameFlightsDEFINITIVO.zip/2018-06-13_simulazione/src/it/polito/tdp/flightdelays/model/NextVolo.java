package it.polito.tdp.flightdelays.model;

import java.sql.Date;

public class NextVolo {
	
	double ritardo;
	int nextAirportID;
	Date newDate;
	
	public NextVolo(int next, double rit, Date date) {
		this.ritardo = rit;
		this.nextAirportID = next;
		this.newDate = date;
		
	}

	public double getRitardo() {
		return ritardo;
	}

	public void setRitardo(double ritardo) {
		this.ritardo = ritardo;
	}

	public int getNextAirportID() {
		return nextAirportID;
	}

	public void setNextAirportID(int nextAirportID) {
		this.nextAirportID = nextAirportID;
	}

	public Date getNewDate() {
		return newDate;
	}

	public void setNewDate(Date newDate) {
		this.newDate = newDate;
	}
	
	
	
	
	

}
