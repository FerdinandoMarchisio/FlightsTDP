package it.polito.tdp.flightdelays.model;

import java.sql.Date;
import java.time.LocalDate;

public class Passaggero {
	
	Airport origin;
	Airport current;
	double ritardo;
	int count;
	Date date;
	
	public Passaggero(Airport o, Airport c) {
		this.origin = o;
		this.current = c;
		this.count=0;
		this.date = null;
		this.ritardo = 0;
		 
		 
		
		
	}

	public Airport getCurrent() {
		return current;
	}

	public void setCurrent(Airport current) {
		this.current = current;
	}

	public double getRitardo() {
		return ritardo;
	}

	public void setRitardo(double ritardo) {
		this.ritardo += ritardo;
	}

	/*@Override
	public String toString() {
		return "Passaggero: origin=" + origin + " current=" + current + " ritardo=" + ritardo ;
	}*/
	
	public void setCount(int i) {
		this.count+=i;
	}

	public Airport getOrigin() {
		return origin;
	}

	public void setOrigin(Airport origin) {
		this.origin = origin;
	}

	public int getCount() {
		return count;
	}

	

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}
	
	
	
	
	
	
	

	
	

}
