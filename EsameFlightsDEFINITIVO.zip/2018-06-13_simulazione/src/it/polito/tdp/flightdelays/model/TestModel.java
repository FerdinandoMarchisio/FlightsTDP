package it.polito.tdp.flightdelays.model;

public class TestModel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
