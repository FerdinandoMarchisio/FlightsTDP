package it.polito.tdp.flightdelays.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;



import org.jgrapht.Graph;
import org.jgrapht.Graphs;
import org.jgrapht.graph.DefaultWeightedEdge;
import org.jgrapht.graph.SimpleDirectedWeightedGraph;

import com.javadocmd.simplelatlng.LatLng;
import com.javadocmd.simplelatlng.LatLngTool;
import com.javadocmd.simplelatlng.util.LengthUnit;

import it.polito.tdp.flightdelays.db.FlightDelaysDAO;

public class Model {
	
	FlightDelaysDAO dao = new FlightDelaysDAO();
	
	List<Airport> airports = new ArrayList<Airport>();	
	Map<Integer, Airport> airportsM = new TreeMap<Integer,Airport>();
	
	List<Airline> airlines = new ArrayList<Airline>();
	
	List<Flight> voli = new ArrayList<Flight>();
	
	Graph<Airport, DefaultWeightedEdge> graph;
	
	List<Tratta> tratte = new ArrayList<Tratta>();
	
	Airline a;
	
	public Model() {
		this.airports = this.dao.loadAllAirports();
		
		for(Airport a : this.airports) {
			this.airportsM.put(a.getId(), a);
		}
	}

	public List<Airline> getAirlines() {
		this.airlines = this.dao.loadAllAirlines(); 
		// TODO Auto-generated method stub
		return this.airlines;
	}

	public void creaGrafo(Airline a) {
		
		this.a = a;
		this.voli = this.dao.loadAllFlights(a.getId());
		
	  this.graph = new SimpleDirectedWeightedGraph<>(DefaultWeightedEdge.class);
	  
	  Graphs.addAllVertices(this.graph, this.airports);
	  //System.out.print(this.graph.vertexSet().size()+"\n");
	  
	  for(Flight f : this.voli) {
		  Airport o = this.airportsM.get(f.getOriginAirportId());
		  Airport d = this.airportsM.get(f.getDestinationAirportId());
		  if(this.graph.getEdge(o, d)==null) {
			  double peso = calcolaPeso(o,d, f.getAirlineId());
			  Graphs.addEdge(this.graph, o, d, peso);
			  this.tratte.add(new Tratta(o,d,peso));
					  
		 }
	  }
	 // System.out.println(this.graph.edgeSet().size());
		
	}

	private double calcolaPeso(Airport o, Airport d, int id) {
		double mediaRitardo = this.dao.getRitardoMedio(o, d, id);
		double distanza = calcolaDistanza(o, d);
		double peso = mediaRitardo/distanza;
		return peso;
	}

	private double calcolaDistanza(Airport o, Airport d) {
	    double distanza =  LatLngTool.distance(new LatLng(o.getLatitude(), o.getLongitude()), new LatLng(d.getLatitude(),  d.getLongitude()),LengthUnit.KILOMETER);
		return distanza;
	}

	public List<Tratta> getWorst() {
	this.tratte.sort(new ComparatorTratte());
	return this.tratte;
	}

	public List<Passaggero> simulazione(int passeggeri, int voli2) {
		Simulazione sim = new Simulazione(passeggeri, voli2, a, this.graph);
		List<Passaggero> result = sim.doSimulazione();
		
		return result;
		
		
	}
	
	

}
